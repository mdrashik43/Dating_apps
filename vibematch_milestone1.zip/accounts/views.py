from django.http import FileResponse, Http404
from rest_framework import status
from rest_framework.authtoken.models import Token
from rest_framework.decorators import api_view
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.throttling import AnonRateThrottle
from rest_framework.views import APIView

from .models import VerificationRequest
from .serializers import LoginSerializer, MeSerializer, RegisterSerializer


class AuthThrottle(AnonRateThrottle):
    rate = "10/min"


class RegisterView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [AuthThrottle]

    def post(self, request):
        s = RegisterSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        user = s.save()
        token, _ = Token.objects.get_or_create(user=user)
        return Response({"token": token.key, "user": MeSerializer(user).data}, status=201)


class LoginView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [AuthThrottle]

    def post(self, request):
        s = LoginSerializer(data=request.data, context={"request": request})
        s.is_valid(raise_exception=True)
        token, _ = Token.objects.get_or_create(user=s.validated_data["user"])
        return Response({"token": token.key, "user": MeSerializer(s.validated_data["user"]).data})


class LogoutView(APIView):
    def post(self, request):
        Token.objects.filter(user=request.user).delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class MeView(APIView):
    def get(self, request):
        return Response(MeSerializer(request.user).data)


@api_view(["GET"])
def verification_document(request, pk):
    """Only the owner or staff may download a verification document."""
    try:
        vr = VerificationRequest.objects.get(pk=pk)
    except VerificationRequest.DoesNotExist:
        raise Http404
    if not (request.user.is_staff or vr.user_id == request.user.id):
        raise Http404  # do not reveal existence
    resp = FileResponse(vr.document.open("rb"))
    resp["Cache-Control"] = "private, no-store"
    resp["X-Content-Type-Options"] = "nosniff"
    return resp
