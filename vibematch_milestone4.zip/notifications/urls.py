from django.urls import path

from . import views

urlpatterns = [
    path("", views.NotificationListView.as_view(), name="notifications"),
    path("read/", views.MarkReadView.as_view(), name="notifications-read"),
]
